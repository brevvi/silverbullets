# silverbullets
Understanding the customer's business 
