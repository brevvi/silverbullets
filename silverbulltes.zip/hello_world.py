# Hello World!

hello = input(str("What's your name? "))
print("Hello, " + hello + "!")
